class WaterReportModel {
  String khasraNumber;
  String cropType;
  String village;
  String waterSource;
  String fieldSize;

  WaterReportModel(
      {this.khasraNumber,
      this.cropType,
      this.village,
      this.waterSource,
      this.fieldSize});
}
