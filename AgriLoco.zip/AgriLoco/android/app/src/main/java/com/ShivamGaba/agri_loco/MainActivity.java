package com.ShivamGaba.agri_loco;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
